package org.fdroid.database

import android.content.Context
import android.content.pm.ApplicationInfo.FLAG_SYSTEM
import android.content.pm.PackageInfo
import android.os.Build.VERSION.SDK_INT
import androidx.core.content.pm.PackageInfoCompat.getLongVersionCode
import androidx.core.os.LocaleListCompat
import java.util.concurrent.TimeUnit
import org.fdroid.CompatibilityChecker
import org.fdroid.CompatibilityCheckerImpl
import org.fdroid.UpdateChecker
import org.fdroid.index.IndexUtils.getPackageSigner
import org.fdroid.index.v2.SignerV2

public class DbAppChecker(
  db: FDroidDatabase,
  private val context: Context,
  compatibilityChecker: CompatibilityChecker = CompatibilityCheckerImpl(context.packageManager),
  private val updateChecker: UpdateChecker = UpdateChecker(compatibilityChecker),
) {
  private val packageManager = context.packageManager
  private val appDao = db.getAppDao() as AppDaoInt
  private val versionDao = db.getVersionDao() as VersionDaoInt
  private val appPrefsDao = db.getAppPrefsDao() as AppPrefsDaoInt
  private val localeList = LocaleListCompat.getDefault()

  /**
   * Gets all apps that somehow have a special status that warrants the user's attention. These can
   * include apps that:
   * * have updates available ([UpdatableApp])
   * * can not be updated, because we don't have those apps anymore ([NotAvailable])
   * * can not be updated, because all versions have incompatible signer ([NoCompatibleSigner])
   * * could get updated from another repo ([UpdateInOtherRepo])
   * * have known vulnerabilities ([KnownVulnerability])
   */
  public fun getApps(packageInfoMap: Map<String, PackageInfo>): AppCheckResult {
    val updatableApps = ArrayList<UpdatableApp>()
    val appsWithIssue = ArrayList<AppWithIssue>()

    // get all versions for all packages (irrespective of preferred repo)
    // and make them accessible per packageName
    val packageNames = packageInfoMap.keys.toList()
    val versionsByPackage = HashMap<String, ArrayList<Version>>(packageNames.size)
    versionDao.getVersions(packageNames).forEach { version ->
      val versions = versionsByPackage.getOrPut(version.packageName) { ArrayList() }
      versions.add(version)
    }
    // go through all apps (packages) and check for updates
    val preferredRepos = appPrefsDao.getPreferredRepos(packageNames)
    packageInfoMap.forEach processPackage@{ (packageName, packageInfo) ->
      // get versions for this app and try to find an update in them
      val versions = versionsByPackage[packageName]
      val flags = packageInfo.applicationInfo?.flags ?: 0
      if (versions.isNullOrEmpty() && flags and FLAG_SYSTEM == 0) {
        // we have no versions and no system app,
        // so check if we maybe had installed this app in the past
        getUnavailableApp(packageInfo, preferredRepos)?.let { unavailableApp ->
          appsWithIssue.add(unavailableApp)
        }
        return@processPackage // continue
      }
      // we ignore system apps without version
      if (versions == null) return@processPackage // continue
      // get all updates from the versions we found
      // these can be from other repos, have incompatible signers or just are KnownVuln
      val updates =
        updateChecker
          .getUpdates(
            versions = versions,
            allowedSignersGetter = null, // all signers are allowed
            installedVersionCode = getLongVersionCode(packageInfo),
            allowedReleaseChannels = null,
            includeKnownVulnerabilities = true,
            preferencesGetter = { appPrefsDao.getAppPrefsOrNull(packageName) },
          )
          .toList()
      // if there are no updates available, there's nothing left to do for us
      if (updates.isEmpty()) return@processPackage
      // we have updates, so now get some data for us to judge those updates

      // get preferred repo for the current app
      val preferredRepoId =
        preferredRepos[packageName] ?: error("No preferred repo for $packageName")

      // get allowed signers for current app
      // always gives us the oldest signer, even if they rotated certs by now
      @Suppress("DEPRECATION")
      val allowedSigners =
        packageInfo.signatures?.map { getPackageSigner(it.toByteArray()) }?.toSet()
          ?: error("Got no signatures for $packageName")

      // happy path is a preferred and compatible update, so we look for those first
      // for simplicity and safety, we tell the user to make those updates first
      updates.forEach { update ->
        if (update.isOk(preferredRepoId, allowedSigners)) {
          getUpdatableApp(
              version = update,
              installedVersionCode = getLongVersionCode(packageInfo),
              installedVersionName = packageInfo.versionName ?: "???",
            )
            ?.let { app -> updatableApps.add(app) }
          return@processPackage
        }
      }
      // we do have update(s), but there's an issue with them, find out the specific issue
      val appWithIssue =
        appDao.getAppOverviewItem(preferredRepoId, packageName)?.let { app ->
          getAppWithIssue(updates, versions, app, packageInfo, preferredRepoId, allowedSigners)
        }
      appWithIssue?.let { appsWithIssue.add(it) }
    }
    return AppCheckResult(updates = updatableApps, issues = appsWithIssue)
  }

  /**
   * Finds out what the issue with the available update is and return a [AvailableAppWithIssue] if
   * necessary.
   */
  private fun getAppWithIssue(
    updates: List<Version>,
    allVersions: List<Version>,
    app: AppOverviewItem,
    packageInfo: PackageInfo,
    preferredRepoId: Long,
    allowedSigners: Set<String>,
  ): AvailableAppWithIssue? {
    // for simplicity, we only consider the issue of the most recent version
    val update = updates[0]
    val hasCompatibleSigner = update.signer.isCompatibleWith(allowedSigners)
    return when {
      // Update has known vulnerability
      update.hasKnownVulnerability ->
        AvailableAppWithIssue(
          app = app,
          installVersionName = packageInfo.versionName ?: "???",
          installVersionCode = getLongVersionCode(packageInfo),
          issue = KnownVulnerability(preferredRepoId == update.repoId),
        )
      // The signer is compatible, so the update must come from a non-preferred repo.
      hasCompatibleSigner -> {
        // Only flag the compatible update in another repo, if older than a week.
        // This is to prevent short delays in providing updates causing unneeded UX churn.
        val now = System.currentTimeMillis()
        if (now - update.added > TimeUnit.DAYS.toMillis(7))
          AvailableAppWithIssue(
            app = app,
            installVersionName = packageInfo.versionName ?: "???",
            installVersionCode = getLongVersionCode(packageInfo),
            issue = UpdateInOtherRepo(update.repoId),
          )
        else null
      }
      // the update doesn't have a compatible signer, look deeper into signing compatibility
      else ->
        getNoCompatibleSignerApp(
          repoIdWithCompatibleSigner =
            updates.find { it.signer.isCompatibleWith(allowedSigners) }?.repoId,
          app = app,
          versions = allVersions,
          packageInfo = packageInfo,
          preferredRepoId = preferredRepoId,
          allowedSigners = allowedSigners,
        )
    }
  }

  /**
   * Returns a [UnavailableAppWithIssue], in case the app provided with [packageInfo] was installed
   * by us in the past.
   */
  private fun getUnavailableApp(
    packageInfo: PackageInfo,
    preferredRepos: Map<String, Long>,
  ): UnavailableAppWithIssue? {
    // check if we installed the app or are the current update owner of this app
    val weInstalledApp = weInstalledApp(packageInfo.packageName)
    if (weInstalledApp) {
      // we had installed this app, check if we maybe just got no versions
      val app =
        preferredRepos[packageInfo.packageName]?.let { repoId ->
          appDao.getAppOverviewItem(repoId, packageInfo.packageName)
        }
      // we still have the app, so we just didn't get versions for it,
      // like when the user was ignoring all updates for the app
      if (app != null) return null
      // warn the user that this app isn't available anymore
      val notAvailable =
        UnavailableAppWithIssue(
          packageName = packageInfo.packageName,
          name = packageInfo.applicationInfo?.loadLabel(packageManager),
          installVersionName = packageInfo.versionName ?: "???",
          installVersionCode = getLongVersionCode(packageInfo),
        )
      return notAvailable
    }
    return null
  }

  /**
   * Returns [AvailableAppWithIssue] with [NoCompatibleSigner], if the app has an update in a repo,
   * but all versions have an incompatible signer.
   *
   * @param repoIdWithCompatibleSigner the ID of the [Repository] that does have a compatible
   *   signer. Null if no repository has a compatible signer.
   */
  private fun getNoCompatibleSignerApp(
    repoIdWithCompatibleSigner: Long?,
    app: AppOverviewItem,
    versions: List<Version>,
    packageInfo: PackageInfo,
    preferredRepoId: Long,
    allowedSigners: Set<String>,
  ): AvailableAppWithIssue? {
    return if (repoIdWithCompatibleSigner == null) {
      // all updates are not compatible, we only warn about this,
      // if all versions in the preferred repo aren't compatible
      val allIncompatible = versions.all { version ->
        version.repoId != preferredRepoId || !version.isOk(preferredRepoId, allowedSigners)
      }
      if (allIncompatible) {
        // possibly the wrong repo was preferred, try to find the right one
        val repoId =
          versions
            .find {
              // treat the current repo as preferred, so we only look at signers
              it.isOk(it.repoId, allowedSigners)
            }
            ?.repoId
        if (repoId == null) {
          // the app may have been installed with another installer
          val installerPackageName =
            if (SDK_INT >= 30) {
              packageManager.getInstallSourceInfo(packageInfo.packageName).installingPackageName
            } else {
              @Suppress("DEPRECATION") // no other choice to use this for old API versions
              packageManager.getInstallerPackageName(packageInfo.packageName)
            }
          // if there is another installer, we don't warn, but leave things to them
          if (installerPackageName != null && installerPackageName != context.packageName)
            return null
        }
        AvailableAppWithIssue(
          app = app,
          installVersionName = packageInfo.versionName ?: "???",
          installVersionCode = getLongVersionCode(packageInfo),
          issue = NoCompatibleSigner(repoId),
        )
      } else {
        // there was at least one compatible version in a repo,
        // so there's hope the update will arrive there
        null
      }
    } else {
      AvailableAppWithIssue(
        app = app,
        installVersionName = packageInfo.versionName ?: "???",
        installVersionCode = getLongVersionCode(packageInfo),
        issue = NoCompatibleSigner(repoIdWithCompatibleSigner),
      )
    }
  }

  /** The given [version] is a normal update, so return a [UpdatableApp] for it. */
  private fun getUpdatableApp(
    version: Version,
    installedVersionCode: Long,
    installedVersionName: String,
  ): UpdatableApp? {
    val versionedStrings =
      versionDao.getVersionedStrings(
        repoId = version.repoId,
        packageName = version.packageName,
        versionId = version.versionId,
      )
    val appOverviewItem =
      appDao.getAppOverviewItem(version.repoId, version.packageName) ?: return null
    return UpdatableApp(
      repoId = version.repoId,
      packageName = version.packageName,
      installedVersionCode = installedVersionCode,
      installedVersionName = installedVersionName,
      update = version.toAppVersion(versionedStrings),
      isFromPreferredRepo = true,
      hasKnownVulnerability = version.hasKnownVulnerability,
      name = appOverviewItem.getName(localeList),
      summary = appOverviewItem.getSummary(localeList),
      localizedIcon = appOverviewItem.localizedIcon,
    )
  }

  /**
   * @return true if this version is an update from the preferred repo with a compatible signer and
   *   not a known vulnerable version.
   */
  private fun Version.isOk(preferredRepoId: Long, signers: Set<String>): Boolean {
    return preferredRepoId == repoId && !hasKnownVulnerability && signer.isCompatibleWith(signers)
  }

  private fun SignerV2?.isCompatibleWith(allowedSigners: Set<String>): Boolean {
    val signers = this?.sha256?.toSet()
    return signers == null || signers.intersect(allowedSigners).isNotEmpty()
  }

  private fun weInstalledApp(packageName: String): Boolean {
    return if (SDK_INT >= 30) {
      val installInfo = packageManager.getInstallSourceInfo(packageName)
      val ourPackage = context.packageName
      ourPackage == installInfo.initiatingPackageName ||
        ourPackage == installInfo.installingPackageName ||
        (SDK_INT >= 34 && ourPackage == installInfo.updateOwnerPackageName)
    } else {
      @Suppress("DEPRECATION")
      context.packageName == packageManager.getInstallerPackageName(packageName)
    }
  }
}
