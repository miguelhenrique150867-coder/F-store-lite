package org.fdroid.ui.navigation

import androidx.compose.runtime.Composable

@Composable
fun BottomBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    //

